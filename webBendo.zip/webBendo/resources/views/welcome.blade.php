<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dusun Bendo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
        <!-- Fonts -->
        <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        
    </head>
    <body class="antialiased">
          <header>
        <nav>
            <div class="logo">Dusun Bendo</div>
            <ul>
                <li><a href="#beranda">Beranda</a></li>
                <li><a href="#tentang">Tentang</a></li>
                <li><a href="#galeri">Galeri</a></li>
                <li><a href="#berita">Berita</a></li>
                <li><a href="#layanan">Layanan</a></li>
                <li><a href="#kontak">Kontak</a></li>
            </ul>
        </nav>
    </header>
    
    <section id="beranda" class="hero">
        <h1>Selamat Datang di Dusun Bendo</h1>
        <p>Melestarikan tradisi, membangun masa depan.</p>
        <a href="#tentang" class="cta">Jelajahi Dusun</a>
    </section>
    
    <section id="tentang">
        <h2>Tentang Dusun Bendo</h2>
        <p>Dusun Bendo adalah desa yang kaya akan budaya dan potensi alam.</p>
    </section>
    
    <section id="galeri">
        <h2>Galeri</h2>
        <div class="gallery">
            <img src="img1.jpg" alt="Gambar 1">
            <img src="img2.jpg" alt="Gambar 2">
        </div>
    </section>
    
    <section id="berita">
        <h2>Berita Terkini</h2>
        <article>
            <h3>Festival Budaya</h3>
            <p>Kemeriahan festival budaya yang menampilkan kesenian lokal.</p>
        </article>
    </section>
    
    <section id="kontak">
        <h2>Hubungi Kami</h2>
        <form>
            <input type="text" placeholder="Nama">
            <input type="email" placeholder="Email">
            <textarea placeholder="Pesan"></textarea>
            <button type="submit">Kirim</button>
        </form>
    </section>
    
    <footer>
        <p>&copy; 2025 Dusun Bendo. All rights reserved.</p>
    </footer>
    </body>
</html>
